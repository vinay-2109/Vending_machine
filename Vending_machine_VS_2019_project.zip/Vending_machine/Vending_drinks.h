// Vending_machine.h : This file contains the Class Drink_attribute and Drinks

#pragma once
#include <iostream>
#include <vector>

using namespace std;

/* Class Drink_attribute interface
update in future for adding more attributes*/

class Drink_attribute
{
private:
	string drink_name;
	float drink_price;
	unsigned quantity;
public:
	Drink_attribute() = delete; // deleted default constructor 
	Drink_attribute(string drinkname, unsigned quant, float drinkprice)
	{
		drink_name = drinkname;
		drink_price = drinkprice;
		quantity = quant;
	}

	string Get_drink_name() { return drink_name; }
	float Get_drink_price() { return drink_price;}
	unsigned Get_quantity() { return quantity; }
	void Set_quantity(int x) { quantity = x; }
};


/* Class Drinks interface
methods for performing oprerations on Drink_attribute */

class Drinks
{
private:
	vector<Drink_attribute> item;
	static Drinks* instance;
	Drinks() {}

public:
	static Drinks* getInstance();
	unsigned numberofitem() { return item.size(); }
	void add_item(string , unsigned , float);
	void display_menu();
	void select_user_drink(unsigned);
};

//Initialize pointer to zero so that it can be initialized in first call to getInstance function
Drinks* Drinks::instance = 0;

// Function to initilaze instance of Class drinks
Drinks* Drinks::getInstance()
{
	if (instance == 0)
	{
		instance = new Drinks();
	}

	return instance;
}

// Function to Add new items in menu
void Drinks::add_item(string drinkname, unsigned quant, float drinkprice)
{
	Drink_attribute drink_atrrib(drinkname, quant, drinkprice);
	item.push_back(drink_atrrib);
}

//Function to display Menu to machine user
void Drinks::display_menu()
{
	int count = 1;
	std::cout << "\nCODE" << "    Drink" "\t  Price" << "\t  Quntity_Remaining";
	for (auto it = item.begin(); it != item.end(); it++)
	{
		std::cout << "\n " << count++ << "      " << it->Get_drink_name() << "\t  " << it->Get_drink_price() << "\t  " << it->Get_quantity();
	}
	std::cout << "\n " << count++ <<  "     Selection completed leave the machine.";
}


//Function to select drink from menu as per user inputs

void Drinks::select_user_drink(unsigned input)
{
	float money, total;
	if (input >= 1 && input <= numberofitem())
	{
		if (item[input - 1].Get_quantity() == 0)
			std::cout << "SORRY !! " << item[input - 1].Get_drink_name() << " Is OUT OF STOCK. Select other drinks\n";
		else
		{
			std::cout << "\n Enter amount to buy product::";
			std::cin >> money;
			while (cin.fail()) // validate user inputs
			{
				//Clear the fail state.
				cin.clear();
				//Ignore the rest of the wrong user input, till the end of the line.
				cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
				std::cout << "\n Enter valid amount or enter 0 to cancel transaction:: :: ";
				std::cin >> money;
			}


			total = money;
			while ((item[input - 1].Get_drink_price()) > total)
			{
				std::cout << "\n Enter more amount to buy product or enter 0 to cancel transaction::";
				std::cin >> money;
				total += money;
				if (money == 0)
				{
					std::cout << "\n Collect your money Rs ::" << total;
					std::cout << "\n Visit again !!";
					return;
				}
		}
        if (total > (item[input - 1].Get_drink_price()))
			std::cout << "\n Collect your change of Rs ::" << total- item[input - 1].Get_drink_price();
		
		//reduce quantity by 1
		item[input - 1].Set_quantity(item[input - 1].Get_quantity()-1);
		std::cout << "\n Enjoy yor Drink !! \n ";
		}
	}



}