// Vending_machine.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "Vending_drinks.h"

using namespace std;


int main()
{
    Drinks *inst =  inst->getInstance();

    // Add items in menu
    inst->add_item("Cola" ,    10,  18.25);
    inst->add_item("Pepsi",    15,  20.00);
    inst->add_item("Beer" ,    20,  130.00);
    inst->add_item("Water",    5,   22.00);
    inst->add_item("MAZA",     0,  85.50);
 
    
    unsigned drink_selection = 0;

    while (drink_selection != inst->numberofitem() + 1)
    {
        inst->display_menu();
        std::cout << "\n\n Enter your choice:: ";
        std::cin >> drink_selection;
        while (cin.fail())
        {
            //Clear the fail state.
            cin.clear();
            //Ignore the rest of the wrong user input, till the end of the line.
            cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "\n Enter valid choices from menu :: ";
            std::cin >> drink_selection;
        }
        inst->select_user_drink(drink_selection);
        

    }
    
    
}

